<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://github.com/user-attachments/assets/0aa67016-6eaf-458a-adb2-6e31a0763ed6" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/drive/1oiki-iHCL8b33YVZ_hfi0JXzFk04FKRw

## Run Locally

**Prerequisites:**  Node.js 18+.

This repository contains both a React frontend and an Express backend.

1. **Install dependencies:**
   Navigate to the project root and run:
   ```bash
   npm install
   ```
   > Note: Installation requires access to the npm registry. If you see
   > 403/404 errors, ensure that your network permits npm downloads.

2. **Configure environment variables:**
   - Copy the file `.env.local` and update the API keys for each provider you
     wish to use (`GEMINI_API_KEY`, `CLAUDE_API_KEY`, `OPENAI_API_KEY`).
   - Optionally set `JWT_SECRET` for token generation.

3. **Run the backend server:**
   The backend provides REST APIs for authentication, program management,
   text storage, and AI generation. Start it with:
   ```bash
   npm run start:backend
   ```
   It will listen on port 3001 by default (configurable via the `PORT` env).

4. **Run the frontend:**
   In a separate terminal, start the Vite development server:
   ```bash
   npm run dev
   ```
   The frontend is configured to proxy API requests to `/api` to your backend
   during development. Visit `http://localhost:5173` in your browser.

5. **Production build:**
   To create a production build of the frontend, run:
   ```bash
   npm run build
   ```
   The static files will be output to the `dist` folder. You can then
   deploy the frontend to any static hosting service (e.g. Vercel, Netlify)
   and deploy the backend separately on a Node.js platform (e.g. Render,
   Heroku). Ensure the frontend is configured to send API requests to your
   backend's URL.

## Features in the basic prototype

This initial version provides a foundation for a comprehensive AI journalism
platform. Implemented features include:

- **User authentication** via JSON Web Tokens (register/login endpoints).
- **Program management**: create and list your content programs.
- **Text storage**: save original and edited texts with associated styles.
- **Unified AI generation endpoint**: generate text using Gemini, Claude, or
  ChatGPT by specifying the desired model.
- **In-memory data storage**: ideal for rapid prototyping. You can later
  replace this with a persistent database.

The groundwork is laid for more advanced functionality, such as style
learning, fact-checking, episode planning, and multimedia integration,
which can be built on top of this architecture.
