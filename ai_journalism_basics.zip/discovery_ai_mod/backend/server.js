/*
 * Backend proxy server for the Discovery AI application.
 *
 * This Express server exposes endpoints that forward user prompts to the
 * configured AI providers (Gemini, Claude, ChatGPT) and return the
 * generated text. API keys are stored in environment variables so that
 * they are never exposed to the browser. Optional social media posting
 * stubs are also provided; you can extend these with real integrations
 * if desired.
 */

import express from 'express';
import fetch from 'node-fetch';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';

const app = express();
app.use(express.json());

// Load API keys from environment variables. Make sure to set these in
// your deployment environment (.env file, Render environment, etc.).
const {
  GEMINI_API_KEY,
  CLAUDE_API_KEY,
  OPENAI_API_KEY,
  TWITTER_BEARER_TOKEN,
  FACEBOOK_ACCESS_TOKEN,
  LINKEDIN_ACCESS_TOKEN,
  JWT_SECRET,
} = process.env;

// Enable CORS in development. Adjust the origin as needed for production.
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type,Authorization');
  next();
});

/**
 * ================================================================
 *  Simple in-memory storage and authentication for the journalism
 *  application. These data structures are used to store user
 *  accounts, programs, texts and style preferences during the
 *  prototype phase. In a production system, these would be
 *  persisted in a database (e.g. PostgreSQL, MongoDB).
 */

// In-memory users: { username: { passwordHash, id } }
const users = {};
// In-memory texts: array of { id, userId, programId, original, edited, stylePattern }
const texts = [];
// In-memory programs: array of { id, userId, name, description, examples, styleGuidelines, targetAudience }
const programs = [];
// Simple ID generators
let nextUserId = 1;
let nextTextId = 1;
let nextProgramId = 1;

// Helper to hash passwords (for demonstration; uses sha256)
function hashPassword(password) {
  return crypto.createHash('sha256').update(password).digest('hex');
}

// Middleware to authenticate JWT tokens
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Missing token' });
  try {
    const decoded = jwt.verify(token, JWT_SECRET || 'secret');
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(403).json({ error: 'Invalid token' });
  }
}

/**
 * Authentication endpoints
 */
app.post('/api/auth/register', (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required' });
  }
  if (users[username]) {
    return res.status(400).json({ error: 'Username already exists' });
  }
  const id = nextUserId++;
  users[username] = {
    id,
    passwordHash: hashPassword(password),
  };
  const token = jwt.sign({ id, username }, JWT_SECRET || 'secret', { expiresIn: '7d' });
  res.json({ token, user: { id, username } });
});

app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body || {};
  const user = users[username];
  if (!user) {
    return res.status(400).json({ error: 'Invalid credentials' });
  }
  const passwordHash = hashPassword(password);
  if (passwordHash !== user.passwordHash) {
    return res.status(400).json({ error: 'Invalid credentials' });
  }
  const token = jwt.sign({ id: user.id, username }, JWT_SECRET || 'secret', { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, username } });
});

/**
 * CRUD endpoints for programs
 */
app.get('/api/programs', authenticateToken, (req, res) => {
  // Return programs belonging to the authenticated user
  const userId = req.user.id;
  const userPrograms = programs.filter((p) => p.userId === userId);
  res.json(userPrograms);
});

app.post('/api/programs', authenticateToken, (req, res) => {
  const { name, description, examples, styleGuidelines, targetAudience } = req.body || {};
  if (!name) {
    return res.status(400).json({ error: 'Program name is required' });
  }
  const program = {
    id: nextProgramId++,
    userId: req.user.id,
    name,
    description: description || '',
    examples: examples || [],
    styleGuidelines: styleGuidelines || '',
    targetAudience: targetAudience || '',
  };
  programs.push(program);
  res.status(201).json(program);
});

/**
 * CRUD endpoints for texts
 */
app.get('/api/texts', authenticateToken, (req, res) => {
  const userId = req.user.id;
  const userTexts = texts.filter((t) => t.userId === userId);
  res.json(userTexts);
});

app.post('/api/texts', authenticateToken, (req, res) => {
  const { programId, original, edited, stylePattern } = req.body || {};
  if (!original) {
    return res.status(400).json({ error: 'Original text is required' });
  }
  const textRecord = {
    id: nextTextId++,
    userId: req.user.id,
    programId: programId || null,
    original,
    edited: edited || null,
    stylePattern: stylePattern || null,
  };
  texts.push(textRecord);
  res.status(201).json(textRecord);
});

/**
 * Unified AI generation endpoint. Accepts a prompt and model type.
 * Model can be 'gemini', 'claude', or 'chatgpt'.
 */
app.post('/api/ai/generate', authenticateToken, async (req, res) => {
  const { prompt, model, useSearch } = req.body || {};
  if (!prompt || !model) {
    return res.status(400).json({ error: 'Prompt and model are required' });
  }
  try {
    let text;
    switch (model) {
      case 'gemini':
        text = await generateGemini(prompt, useSearch);
        break;
      case 'claude':
        text = await generateClaude(prompt);
        break;
      case 'chatgpt':
        text = await generateChatGPT(prompt);
        break;
      default:
        return res.status(400).json({ error: `Unknown model: ${model}` });
    }
    res.json({ text });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message || 'Error generating content' });
  }
});

/**
 * Helper to call the Google Gemini API. Uses the generative language API to
 * generate content from a user prompt. See
 * https://ai.google.dev/api/rest/v1beta/models/generateContent for details.
 *
 * @param {string} prompt User prompt
 * @param {boolean} useSearch Whether to enable Google search augmentation (currently unused)
 * @returns {Promise<string>} Generated text
 */
async function generateGemini(prompt, useSearch = true) {
  if (!GEMINI_API_KEY) {
    throw new Error('GEMINI_API_KEY is not set');
  }
  const model = 'gemini-pro';
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${GEMINI_API_KEY}`;
  const body = {
    contents: [
      {
        role: 'user',
        parts: [{ text: prompt }],
      },
    ],
    // Provide generation config if you want to control max tokens, temperature, etc.
    generationConfig: {
      maxOutputTokens: 2048,
      temperature: 0.7,
    },
    // Tools are currently unused; search functionality could be enabled via tools field.
  };
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!response.ok) {
    const errorBody = await response.text();
    throw new Error(`Gemini API request failed: ${response.status} - ${errorBody}`);
  }
  const data = await response.json();
  const candidate = data?.candidates?.[0];
  // Each candidate contains a content with parts array. Concatenate text parts.
  const text = candidate?.content?.parts?.map((p) => p.text).join('') || '';
  return text;
}

/**
 * Call Claude (Anthropic) API. See https://docs.anthropic.com/claude/reference/messages_post for details.
 *
 * @param {string} prompt User prompt
 * @returns {Promise<string>} Generated text
 */
async function generateClaude(prompt) {
  if (!CLAUDE_API_KEY) {
    throw new Error('CLAUDE_API_KEY is not set');
  }
  const url = 'https://api.anthropic.com/v1/messages';
  const body = {
    model: 'claude-3-opus-20240229',
    messages: [ { role: 'user', content: prompt } ],
    max_tokens: 2048,
  };
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'x-api-key': CLAUDE_API_KEY,
      'anthropic-version': '2023-06-01',
      'content-type': 'application/json',
    },
    body: JSON.stringify(body),
  });
  if (!response.ok) {
    const errorBody = await response.text();
    throw new Error(`Claude API request failed: ${response.status} - ${errorBody}`);
  }
  const data = await response.json();
  const text = data?.content?.[0]?.text || '';
  return text;
}

/**
 * Call ChatGPT (OpenAI) API. See https://platform.openai.com/docs/api-reference/chat/create for details.
 *
 * @param {string} prompt User prompt
 * @returns {Promise<string>} Generated text
 */
async function generateChatGPT(prompt) {
  if (!OPENAI_API_KEY) {
    throw new Error('OPENAI_API_KEY is not set');
  }
  const url = 'https://api.openai.com/v1/chat/completions';
  const body = {
    model: 'gpt-4o',
    messages: [ { role: 'user', content: prompt } ],
    max_tokens: 2048,
  };
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${OPENAI_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });
  if (!response.ok) {
    const errorBody = await response.text();
    throw new Error(`ChatGPT API request failed: ${response.status} - ${errorBody}`);
  }
  const data = await response.json();
  const text = data?.choices?.[0]?.message?.content || '';
  return text;
}

// Routes
app.post('/api/generate-gemini', async (req, res) => {
  const { prompt, useSearch } = req.body || {};
  try {
    const text = await generateGemini(prompt, useSearch);
    res.json({ text });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message || 'Error generating Gemini content' });
  }
});

app.post('/api/generate-claude', async (req, res) => {
  const { prompt } = req.body || {};
  try {
    const text = await generateClaude(prompt);
    res.json({ text });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message || 'Error generating Claude content' });
  }
});

app.post('/api/generate-chatgpt', async (req, res) => {
  const { prompt } = req.body || {};
  try {
    const text = await generateChatGPT(prompt);
    res.json({ text });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message || 'Error generating ChatGPT content' });
  }
});

/**
 * Stub endpoint for posting to social media. To enable automatic posting, you
 * should implement calls to the corresponding social media APIs (Twitter,
 * Facebook, LinkedIn, etc.) and store the necessary access tokens as
 * environment variables. This stub simply logs the request and returns
 * a success message.
 */
app.post('/api/post-social', async (req, res) => {
  const { platform, content } = req.body || {};
  console.log(`Received request to post to ${platform}: ${content}`);
  // TODO: Implement actual API call for each platform using the appropriate
  // access token from environment variables (TWITTER_BEARER_TOKEN, etc.).
  res.json({ message: `Simulated posting to ${platform}. This feature is not yet implemented.` });
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok' });
});

const port = process.env.PORT || 3001;
app.listen(port, () => {
  console.log(`AI proxy server listening on port ${port}`);
});