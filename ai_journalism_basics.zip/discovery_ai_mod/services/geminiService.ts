
// Removed direct imports from @google/genai since API calls are now proxied via our backend
import type { GenerateContentResponse } from "@google/genai";
// FIX: The 'Model' enum was imported as a type, causing errors when used as a value (e.g., Model.GEMINI). This moves it to a value import.
import type { Program, ApiKeys, Source, Message } from '../types';
import { Mode, Model } from '../types';

// Base path for our backend API. All AI requests will be routed through this server to
// securely inject API keys and avoid exposing them in the client.
const API_BASE = '';

// --- Low-level API Call Functions ---

/**
 * Call the Claude (Anthropic) model via the backend. The backend will inject
 * the API key from its environment and forward the request to Anthropic's API.
 *
 * @param prompt The user prompt
 */
const callClaude = async (prompt: string): Promise<string> => {
    const response = await fetch(`${API_BASE}/api/generate-claude`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ prompt }),
    });
    if (!response.ok) {
        const errorBody = await response.text();
        throw new Error(`Claude API request failed: ${response.status} - ${errorBody}`);
    }
    const data = await response.json();
    return data.text || '';
};

/**
 * Call the ChatGPT (OpenAI) model via the backend. The backend will inject
 * the API key from its environment and forward the request to OpenAI's API.
 *
 * @param prompt The user prompt
 */
const callChatGPT = async (prompt: string): Promise<string> => {
    const response = await fetch(`${API_BASE}/api/generate-chatgpt`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ prompt }),
    });
    if (!response.ok) {
        const errorBody = await response.text();
        throw new Error(`ChatGPT API request failed: ${response.status} - ${errorBody}`);
    }
    const data = await response.json();
    return data.text || '';
};

const callOtherModel = async (prompt: string, model: Model): Promise<string> => {
    switch (model) {
        case Model.CLAUDE:
            return callClaude(prompt);
        case Model.CHATGPT:
            return callChatGPT(prompt);
        case Model.OTHER:
            // Placeholder for another model's API call
            console.warn("Model.OTHER is not implemented. Please replace with actual API call.");
            return `This is a simulated response from ${model}.`;
        default:
            throw new Error(`Model ${model} is not supported for direct calls.`);
    }
};

// Gemini model configuration is handled on the backend; the client no longer
// directly constructs a GoogleGenAI instance or exposes the API key.

const extractSourcesFromMarkdown = (text: string): Source[] => {
    const regex = /\[([^\]]+)\]\(([^)]+)\)/g;
    const sources: Source[] = [];
    let match;
    while ((match = regex.exec(text)) !== null) {
        // Avoid adding image links or internal links
        if (match[2].startsWith('http')) {
            sources.push({ title: match[1], uri: match[2] });
        }
    }
    return sources;
};


// When calling via the backend, we won't receive grounding metadata from Gemini,
// so we extract sources only from markdown-style links present in the returned text.
const parseSourcesFromResponse = (_response: any, text: string): Source[] => {
    return extractSourcesFromMarkdown(text);
};

/**
 * Generate content using the Gemini model via the backend. The backend handles
 * authentication and optional search configuration. The client only sends the
 * prompt and whether to use Google Search.
 *
 * @param prompt User prompt
 * @param useSearch Whether to enable Google Search (few-shot retrieval)
 */
const generateGeminiContent = async (prompt: string, useSearch: boolean): Promise<{ text: string; sources: Source[] }> => {
    try {
        const response = await fetch(`${API_BASE}/api/generate-gemini`, {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ prompt, useSearch }),
        });
        if (!response.ok) {
            const errorBody = await response.text();
            throw new Error(`Gemini API request failed: ${response.status} - ${errorBody}`);
        }
        const data = await response.json();
        const text: string = data.text || '';
        const sources: Source[] = parseSourcesFromResponse(null, text);
        return { text, sources };
    } catch (error) {
        console.error("Error calling Gemini API:", error);
        throw new Error("فشل في الحصول على استجابة من الخادم.");
    }
};

// Generic Orchestrator for all features
const orchestrateGeneration = async (
    createPrompt: () => string,
    mode: Mode,
    model: Model,
    _apiKeys: ApiKeys
): Promise<{ result: string; sources: Source[] }> => {
    const initialPrompt = createPrompt();

    if (mode === Mode.SINGLE || model === Model.GEMINI) {
        if (model === Model.GEMINI) {
            const { text, sources } = await generateGeminiContent(initialPrompt, true);
            return { result: text, sources };
        } else {
            const text = await callOtherModel(initialPrompt, model);
            const sources = extractSourcesFromMarkdown(text);
            return { result: text, sources };
        }
    }

    if (mode === Mode.HYBRID) {
        const [geminiResult, otherResult] = await Promise.all([
            generateGeminiContent(initialPrompt, true),
            callOtherModel(initialPrompt, model)
        ]);

        const mergePrompt = `
أنت محرر خبير ومخرج مبدع. لديك نسختان من محتوى تم إنشاؤه لنفس الطلب. مهمتك هي دمج أفضل الأفكار، والأسلوب، والمعلومات من كلتا النسختين لإنشاء نسخة نهائية متفوقة. حافظ على الحقائق الدقيقة والمصادر الموثوقة.

النسخة الأولى (من Gemini):
---
${geminiResult.text}
---

النسخة الثانية (من ${model}):
---
${otherResult}
---

الآن، قم بإنشاء النسخة النهائية المدمجة والمحسنة. يجب أن تكون متماسكة، جذابة، وتحافظ على جميع المصادر المذكورة في كلا النصين.
`;
        const { text, sources } = await generateGeminiContent(mergePrompt, true);
        return { result: text, sources };
    }

    if (mode === Mode.CROSS_CHECK) {
        const geminiResult = await generateGeminiContent(initialPrompt, true);
        const reviewPrompt = `
أنت مدقق حقائق ومراجع محتوى خبير. قم بتحليل النص التالي الذي أنشأه نموذج ذكاء اصطناعي آخر.
مهمتك هي تقييم دقته، وتماسكه، وجودته. قدم ملاحظات بناءة، وصحح أي أخطاء، واقترح تحسينات.

النص للمراجعة:
---
${geminiResult.text}
---

قدم مراجعتك النقدية.
`;
        const review = await callOtherModel(reviewPrompt, model);
        const revisionPrompt = `
أنت كاتب سيناريو خبير. لقد تلقيت الملاحظات التالية من مراجع خبير حول المسودة الأولية لنصك.
مهمتك هي مراجعة النص الأصلي بعناية وتطبيق التعديلات المقترحة لتحسين جودته ودقته.

النص الأصلي:
---
${geminiResult.text}
---

ملاحظات المراجع:
---
${review}
---

الآن، أعد كتابة النص الأصلي مع دمج هذه الملاحظات لإنتاج نسخة نهائية محسنة.
`;
        const { text, sources } = await generateGeminiContent(revisionPrompt, true);
        return { result: text, sources };
    }

    // Fallback for safety
    const { text, sources } = await generateGeminiContent(initialPrompt, true);
    return { result: text, sources };
};


// --- Script Generation ---
const createScriptPrompt = (program: Program, topic: string) => `
أنت كاتب سيناريو محترف ومبدع متخصص في إنشاء محتوى فيديو قصير لمنصات مثل TikTok و Instagram Reels.
مهمتك هي كتابة نص كامل ومفصل لحلقة حول الموضوع التالي: "${topic}".
يجب أن يكون النص دقيقًا وموثقًا، حيث **يجب عليك تضمين مصدر كل معلومة تقدمها مباشرة في النص** على شكل رابط هايبرلينك بصيغة ماركداون [العنوان](الرابط).

**تفاصيل البرنامج:**
- **اسم البرنامج:** "${program.name}"
- **النوع:** ${program.genre}
- **الجمهور المستهدف:** ${program.targetAudience}
- **مدة الحلقة:** ${program.episodeLength}

**النصوص المرجعية لأسلوب البرنامج (يجب الالتزام الصارم بنفس النبرة والأسلوب):**
${program.styleReferences.map(ref => `- "${ref.substring(0, 200)}..."`).join('\n')}

**المتطلبات:**
1.  **عنوان جذاب:** ابدأ النص بـ "عنوان الحلقة: " متبوعًا بالعنوان بين علامتي اقتباس.
2.  **الالتزام بالأسلوب:** يجب أن يكون النص النهائي محاكاة دقيقة لأسلوب ونبرة النصوص المرجعية.
3.  **الدقة والمصادر:** استخدم Google Search للعثور على معلومات دقيقة وحديثة. **كل حقيقة أو رقم أو ادعاء يجب أن يكون مدعومًا بمصدره مباشرةً** في النص.
4.  **الصياغة:** يجب أن يكون النص مكتوبًا بلغة عربية فصيحة وجذابة ومناسبة لمنصات الفيديو القصيرة.
`;

export const generateScript = async (program: Program, topic:string, mode: Mode, model: Model, apiKeys: ApiKeys): Promise<{script: string, sources: Source[]}> => {
    const { result, sources } = await orchestrateGeneration(() => createScriptPrompt(program, topic), mode, model, apiKeys);
    return { script: result, sources };
};

// --- Episode Ideas ---
const createIdeasPrompt = (program: Program) => `
أنت خبير في إنشاء الأفكار الإبداعية لبرامج الفيديو.
البرنامج هو "${program.name}" (${program.genre}). الجمهور هو ${program.targetAudience}.
استنادًا إلى هذه النصوص المرجعية للأسلوب:
${program.styleReferences.map(ref => `- "${ref.substring(0, 200)}..."`).join('\n')}

المهمة: اقترح 5 أفكار جديدة ومبتكرة لحلقات تتبع نفس النمط الموضوعي والأسلوب.
لكل فكرة، قدم عنوانًا مقترحًا ووصفًا موجزًا. استخدم Google Search وتأكد من **دعم كل فكرة بمصدر** يثبت أنها مثيرة للاهتمام أو ذات صلة، وأدرج المصدر كرابط هايبرلينك.
`;

export const generateIdeas = async (program: Program, mode: Mode, model: Model, apiKeys: ApiKeys): Promise<string> => {
     const { result } = await orchestrateGeneration(() => createIdeasPrompt(program), mode, model, apiKeys);
     return result;
};

// --- Deep Research ---
const createResearchPrompt = (topic: string) => `
قم بإجراء بحث معمق وشامل حول الموضوع التالي: "${topic}".
استخدم Google Search للوصول إلى أحدث المعلومات من مصادر موثوقة ومتنوعة.
قدم تقريرًا مفصلاً ومنظمًا. **يجب أن يكون كل ادعاء أو معلومة في التقرير مدعومًا بمصدره المباشر** على شكل رابط هايبرلينك.
`;

export const performDeepResearch = async (topic: string, mode: Mode, model: Model, apiKeys: ApiKeys): Promise<{ research: string, sources: Source[] }> => {
    const { result, sources } = await orchestrateGeneration(() => createResearchPrompt(topic), mode, model, apiKeys);
    return { research: result, sources };
};

// --- Fact Check ---
const createFactCheckPrompt = (text: string) => `
أنت مدقق حقائق خبير. قم بتحليل النص التالي بدقة للتحقق من صحة المعلومات الواردة فيه.
النص: "${text}"

المهمة:
1.  حدد الادعاءات الرئيسية في النص.
2.  لكل ادعاء، استخدم Google Search للتحقق من صحته.
3.  قدم تقريرًا مفصلاً، وصنف كل ادعاء بأنه "**✅ صحيح**"، "**❌ خاطئ**"، أو "**⚠️ صحيح جزئيًا / مختلف عليه**".
4.  **ادعم كل تقييم بأدلة وروابط هايبرلينك للمصادر الموثوقة** التي استخدمتها.
`;

export const checkFacts = async (text: string, mode: Mode, model: Model, apiKeys: ApiKeys): Promise<string> => {
     const { result } = await orchestrateGeneration(() => createFactCheckPrompt(text), mode, model, apiKeys);
     return result;
};


// --- Chat Service ---
let chatInstance: Chat | null = null;
let scriptModificationChatHistory: { role: 'user' | 'model', parts: { text: string }[] }[] = [];


export const startChat = (program: Program): Chat => {
    scriptModificationChatHistory = []; // Reset history for new script chats
    chatInstance = ai.chats.create({
        model: geminiModel,
        config: {
            systemInstruction: `أنت مساعد إبداعي متخصص في برنامج "${program.name}". ساعد المستخدم في تطوير الأفكار، كتابة أجزاء من النصوص، والإجابة على الأسئلة المتعلقة بالبرنامج.`,
        },
    });
    return chatInstance;
};

export const sendChatMessage = async (message: string): Promise<GenerateContentResponse> => {
    if (!chatInstance) {
        throw new Error("Chat not initialized. Call startChat first.");
    }
    return await chatInstance.sendMessage({ message });
};


// --- New Chat to Modify Script ---
export const chatToModifyScript = async (
    program: Program,
    originalTopic: string,
    currentScript: string,
    userInstruction: string,
    model: Model, // Though we primarily use Gemini for this complex task
    apiKeys: ApiKeys
): Promise<{script: string, sources: Source[]}> => {
    
    // Add current interaction to history
    scriptModificationChatHistory.push({ role: 'user', parts: [{ text: userInstruction }] });

    const modificationPrompt = `
أنت كاتب سيناريو خبير ومساعد تعديل. مهمتك هي تعديل نص موجود بناءً على طلب المستخدم.
يجب أن يحافظ النص المعدل على نفس الأسلوب والنبرة الأصلية للبرنامج، وأن يستمر في دعم الحقائق بالمصادر.

**تفاصيل البرنامج:**
- **اسم البرنامج:** "${program.name}"
- **الأسلوب العام:**
${program.styleReferences.map(ref => `- "${ref.substring(0, 150)}..."`).join('\n')}

**سياق الحلقة:**
- **الموضوع الأصلي:** ${originalTopic}
- **النص الحالي:**
---
${currentScript}
---

**سجل التعديلات السابق (إن وجد):**
${scriptModificationChatHistory.slice(0, -1).map(m => `- ${m.role === 'user' ? 'طلب المستخدم' : 'رد النموذج'}: ${m.parts[0].text.substring(0,100)}...`).join('\n')}

**طلب التعديل الأخير من المستخدم:**
"${userInstruction}"

**المهمة:**
أعد كتابة النص **بالكامل** مع تطبيق التعديل المطلوب. تأكد من أن النص الجديد متماسك ويحافظ على الجودة والأسلوب.
`;

    const { text, sources } = await generateGeminiContent(modificationPrompt, true);
    
    // Add model response to history
    scriptModificationChatHistory.push({ role: 'model', parts: [{ text }] });

    return { script: text, sources };
};